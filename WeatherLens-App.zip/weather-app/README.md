# ⛅ WeatherLens — Premium Weather App
### Live weather with dynamic backgrounds & real-time data

---

## 🚀 Features

- **Dynamic Backgrounds** — gradient + animated particles change with weather
  - ☀️ Clear Day → bright blue sky with twinkling stars
  - 🌧️ Rain → dark blue with animated rain drops
  - ❄️ Snow → cool blue with falling snowflakes
  - ⛈️ Thunderstorm → deep dark with heavy rain
  - ☁️ Clouds → slate grey with drifting clouds
  - 🌫️ Mist/Fog → muted teal atmospheric look
  - 🌕 Clear Night → deep dark with stars

- **Real-time Data** from OpenWeatherMap API
- **Current Weather** — temp, feels like, humidity, wind, pressure, visibility, dew point, cloud cover
- **24-Hour Hourly Forecast** — scrollable with rain probability
- **5-Day Forecast** — high/low with weather icons
- **Sunrise & Sunset** times
- **°C / °F** toggle
- **Auto Location** detection (with API key)
- **City Search**
- Glassmorphism UI with animated weather particles

---

## ⚡ Setup (2 minutes)

### 1. Get Free API Key
Go to → https://openweathermap.org/api  
Sign up (free) → copy your API key

### 2. Add Key to Code
Open `index.html`, find line:
```javascript
const API_KEY = 'YOUR_API_KEY_HERE';
```
Replace with your key:
```javascript
const API_KEY = 'abc123yourkey456';
```

### 3. Open
Just open `index.html` in any browser — no server needed!

---

## 📁 Structure
```
weather-app/
└── index.html    ← Everything in one file
```

## 🛠️ Tech Stack
- Vanilla HTML5, CSS3, JavaScript (ES6)
- OpenWeatherMap REST API (free tier)
- Canvas API for particle animations
- CSS Custom Properties for dynamic theming
- async/await for non-blocking API calls

---

## 👨‍💻 Author
**Mahesh Bhardwaj** — GitHub: github.com/maheshbhardwaj99
